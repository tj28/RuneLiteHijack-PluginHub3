Can't seem to get a config gear going. No idea what's happening here.
